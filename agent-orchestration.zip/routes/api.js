const express = require('express');
const router = express.Router();
const https = require('https');
const http = require('http');
const store = require('../data/store');

console.log('[API] Routes loaded - version 3');

// ─── Legacy Databricks Config ───
router.get('/config', (req, res) => {
    res.json(store.getConfig());
});

router.post('/config', (req, res) => {
    const { workspaceUrl, token } = req.body;
    res.json(store.saveConfig({ workspaceUrl, token }));
});

// ─── Workspaces CRUD ───
router.get('/workspaces', (req, res) => {
    res.json(store.getAllWorkspaces());
});

router.get('/workspaces/:id', (req, res) => {
    const ws = store.getWorkspace(req.params.id);
    if (!ws) return res.status(404).json({ error: 'Not found' });
    res.json(ws);
});

router.post('/workspaces', (req, res) => {
    const { name, environment, workspaceUrl, token } = req.body;
    if (!name || !workspaceUrl || !token) return res.status(400).json({ error: 'Name, URL, and token are required' });
    res.json(store.createWorkspace(name, environment || 'dev', workspaceUrl, token));
});

router.put('/workspaces/:id', (req, res) => {
    const result = store.updateWorkspace(req.params.id, req.body);
    if (!result) return res.status(404).json({ error: 'Not found' });
    res.json(result);
});

router.delete('/workspaces/:id', (req, res) => {
    store.deleteWorkspace(req.params.id);
    res.json({ success: true });
});

// ─── List serving endpoints from a specific workspace ───
router.get('/workspaces/:id/endpoints', async (req, res) => {
    const ws = store.getWorkspace(req.params.id);
    if (!ws) return res.json({ endpoints: [], error: 'Workspace not found' });
    try {
        const data = await databricksRequest(ws, 'GET', '/api/2.0/serving-endpoints');
        const endpoints = (data.endpoints || []).filter(ep => !ep.name.startsWith('databricks-')).map(ep => ({
            name: ep.name,
            state: ep.state?.ready || 'UNKNOWN',
            creator: ep.creator,
            creation_timestamp: ep.creation_timestamp
        })).sort((a, b) => (a.state === 'READY' ? 0 : 1) - (b.state === 'READY' ? 0 : 1));
        res.json({ endpoints });
    } catch (err) {
        res.json({ endpoints: [], error: err.message });
    }
});

// ─── Legacy endpoints listing (uses first workspace or old config) ───
router.get('/endpoints', async (req, res) => {
    const workspaces = store.getAllWorkspaces();
    const config = workspaces.length > 0 ? workspaces[0] : store.getConfig();
    if (!config.workspaceUrl || !config.token) {
        return res.json({ endpoints: [], error: 'Databricks not configured' });
    }
    try {
        const data = await databricksRequest(config, 'GET', '/api/2.0/serving-endpoints');
        const endpoints = (data.endpoints || []).filter(ep => !ep.name.startsWith('databricks-')).map(ep => ({
            name: ep.name,
            state: ep.state?.ready || 'UNKNOWN',
            creator: ep.creator,
            creation_timestamp: ep.creation_timestamp
        })).sort((a, b) => (a.state === 'READY' ? 0 : 1) - (b.state === 'READY' ? 0 : 1));
        res.json({ endpoints });
    } catch (err) {
        res.json({ endpoints: [], error: err.message });
    }
});

// ─── Solutions CRUD ───
router.get('/solutions', (req, res) => {
    res.json(store.getAllSolutions());
});

router.get('/solutions/:id', (req, res) => {
    const solution = store.getSolution(req.params.id);
    if (!solution) return res.status(404).json({ error: 'Not found' });
    res.json(solution);
});

router.post('/solutions', (req, res) => {
    const { name, description, workspaceId } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });
    res.json(store.createSolution(name, description || '', workspaceId));
});

router.put('/solutions/:id', (req, res) => {
    const result = store.updateSolution(req.params.id, req.body);
    if (!result) return res.status(404).json({ error: 'Not found' });
    res.json(result);
});

router.delete('/solutions/:id', (req, res) => {
    store.deleteSolution(req.params.id);
    res.json({ success: true });
});

// ─── Workflow Steps ───
router.post('/solutions/:id/steps', (req, res) => {
    const step = store.addStep(req.params.id, req.body);
    if (!step) return res.status(404).json({ error: 'Solution not found' });
    res.json(step);
});

router.put('/solutions/:id/steps/:stepId', (req, res) => {
    const step = store.updateStep(req.params.id, req.params.stepId, req.body);
    if (!step) return res.status(404).json({ error: 'Not found' });
    res.json(step);
});

router.delete('/solutions/:id/steps/:stepId', (req, res) => {
    store.deleteStep(req.params.id, req.params.stepId);
    res.json({ success: true });
});

router.put('/solutions/:id/reorder', (req, res) => {
    const { stepIds } = req.body;
    const steps = store.reorderSteps(req.params.id, stepIds);
    if (!steps) return res.status(404).json({ error: 'Not found' });
    res.json(steps);
});

// ─── Execute Workflow ───
router.post('/solutions/:id/execute', async (req, res) => {
    const solution = store.getSolution(req.params.id);
    if (!solution) return res.status(404).json({ error: 'Solution not found' });

    // Resolve workspace config for this solution
    let config;
    if (solution.workspaceId) {
        config = store.getWorkspace(solution.workspaceId);
    }
    if (!config) {
        const workspaces = store.getAllWorkspaces();
        config = workspaces.length > 0 ? workspaces[0] : store.getConfig();
    }
    if (!config || !config.workspaceUrl || !config.token) {
        return res.status(400).json({ error: 'No workspace configured for this solution' });
    }
    if (solution.steps.length === 0) {
        return res.status(400).json({ error: 'No steps in workflow' });
    }

    const initialInput = req.body.input || '';
    const broadcastMode = req.body.broadcastMode || false;
    const results = [];
    let currentInput = initialInput;
    const priorOutputs = [];

    for (const step of solution.steps.sort((a, b) => a.order - b.order)) {
        let stepInput;
        if (broadcastMode && priorOutputs.length > 0) {
            const context = priorOutputs.map(p => `[${p.stepName} output]: ${p.output}`).join('\n\n');
            stepInput = initialInput + '\n\n--- Previous Agent Results ---\n' + context;
        } else {
            stepInput = currentInput;
        }

        const stepResult = { stepId: step.id, stepName: step.name, endpoint: step.endpointName, status: 'pending', input: stepInput, output: null, error: null, duration: 0 };
        const start = Date.now();
        try {
            const payload = buildPayload(step, stepInput);
            console.log(`[Step: ${step.name}] Mapping: ${step.inputMapping}, Broadcast: ${broadcastMode}`);
            const response = await databricksRequest(config, 'POST', `/serving-endpoints/${step.endpointName}/invocations`, payload);
            stepResult.output = response;
            stepResult.status = 'success';
            currentInput = extractOutput(response);
            priorOutputs.push({ stepName: step.name, output: currentInput });
        } catch (err) {
            stepResult.error = err.message;
            stepResult.status = 'error';
            stepResult.duration = Date.now() - start;
            results.push(stepResult);
            break;
        }
        stepResult.duration = Date.now() - start;
        results.push(stepResult);
    }

    store.updateSolution(solution.id, {
        lastRun: { timestamp: new Date().toISOString(), results, input: initialInput }
    });

    res.json({ solutionId: solution.id, results, finalOutput: currentInput });
});

// ─── Helpers ───
function buildPayload(step, input) {
    if (step.inputMapping === 'messages') {
        return {
            messages: [{ role: 'user', content: typeof input === 'string' ? input : JSON.stringify(input) }]
        };
    }
    if (step.inputMapping === 'input_array') {
        const content = typeof input === 'string' ? input : JSON.stringify(input);
        return {
            input: [{ role: 'user', content: content }]
        };
    }
    if (step.inputMapping === 'dataframe_split') {
        return {
            dataframe_split: { columns: ['input'], data: [[typeof input === 'string' ? input : JSON.stringify(input)]] }
        };
    }
    // passthrough: send as input array by default
    if (typeof input === 'string') {
        return {
            input: [input]
        };
    }
    return input;
}

function extractOutput(response) {
    if (response?.choices?.[0]?.message?.content) return response.choices[0].message.content;
    if (response?.predictions) return response.predictions;
    if (response?.output) return response.output;
    if (typeof response === 'string') return response;
    return JSON.stringify(response);
}

function databricksRequest(config, method, apiPath, body) {
    return new Promise((resolve, reject) => {
        let baseUrl = config.workspaceUrl.replace(/\/+$/, '');
        if (!baseUrl.startsWith('http')) baseUrl = 'https://' + baseUrl;
        const url = new URL(apiPath, baseUrl);
        const isHttps = url.protocol === 'https:';
        const transport = isHttps ? https : http;

        const options = {
            hostname: url.hostname,
            port: url.port || (isHttps ? 443 : 80),
            path: url.pathname + url.search,
            method,
            headers: {
                'Authorization': `Bearer ${config.token}`,
                'Content-Type': 'application/json'
            }
        };

        const req = transport.request(options, (resp) => {
            let data = '';
            resp.on('data', chunk => data += chunk);
            resp.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch {
                    resolve(data);
                }
            });
        });

        req.on('error', reject);
        req.setTimeout(120000, () => { req.destroy(); reject(new Error('Request timeout')); });

        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

module.exports = router;
